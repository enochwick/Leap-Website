</main><!-- #main -->

<footer class="site-footer" id="site-footer" role="contentinfo">

    <!-- Footer CTA Bar -->
    <?php get_template_part( 'template-parts/footer-cta' ); ?>

    <!-- Footer Body -->
    <div class="footer-body">
        <div class="container">
            <div class="footer-grid">

                <!-- Brand column -->
                <div class="footer-brand">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer-logo-link" aria-label="<?php bloginfo( 'name' ); ?>">
                        <svg class="logo-icon" width="28" height="28" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                            <defs>
                                <linearGradient id="footerLogoGrad" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                                    <stop offset="0%" stop-color="#0066FF"/>
                                    <stop offset="100%" stop-color="#00BFFF"/>
                                </linearGradient>
                            </defs>
                            <path d="M4 28L16 4L28 28H20L16 18L12 28H4Z" fill="url(#footerLogoGrad)"/>
                        </svg>
                        <span class="footer-site-name"><?php bloginfo( 'name' ); ?></span>
                    </a>
                    <p class="footer-tagline"><?php bloginfo( 'description' ); ?></p>

                    <!-- Social Links -->
                    <?php if ( has_nav_menu( 'social' ) ) : ?>
                        <nav class="footer-social" aria-label="<?php esc_attr_e( 'Social Links', 'leap-theme' ); ?>">
                            <?php
                            wp_nav_menu( [
                                'theme_location' => 'social',
                                'menu_class'     => 'social-links',
                                'container'      => false,
                                'link_before'    => '<span class="screen-reader-text">',
                                'link_after'     => '</span>',
                                'depth'          => 1,
                            ] );
                            ?>
                        </nav>
                    <?php else : ?>
                        <div class="footer-social">
                            <a href="#" class="social-link" aria-label="Twitter/X">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.253 5.622 5.91-5.622Zm-1.161 17.52h1.833L7.084 4.126H5.117Z"/></svg>
                            </a>
                            <a href="#" class="social-link" aria-label="LinkedIn">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                            </a>
                            <a href="#" class="social-link" aria-label="GitHub">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Nav columns -->
                <div class="footer-nav-col">
                    <h3 class="footer-col-title">Company</h3>
                    <ul class="footer-links">
                        <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About Us</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/services' ) ); ?>">Services</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/pricing' ) ); ?>">Pricing</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/blog' ) ); ?>">Blog</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/news' ) ); ?>">News</a></li>
                    </ul>
                </div>

                <div class="footer-nav-col">
                    <h3 class="footer-col-title">Resources</h3>
                    <ul class="footer-links">
                        <li><a href="#">Documentation</a></li>
                        <li><a href="#">API Reference</a></li>
                        <li><a href="#">Status</a></li>
                        <li><a href="#">Changelog</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Support</a></li>
                    </ul>
                </div>

                <!-- Contact column -->
                <div class="footer-contact-col">
                    <h3 class="footer-col-title">Contact</h3>
                    <?php
                    $contact = leap_field( 'footer_contact_info' );
                    if ( $contact ) {
                        echo wp_kses_post( $contact );
                    } else {
                        echo '<address class="footer-address">
                            <p>hello@yourcompany.com</p>
                            <p>+1 (555) 000-0000</p>
                            <p>123 Innovation Drive<br>San Francisco, CA 94102</p>
                        </address>';
                    }
                    ?>
                </div>

            </div><!-- .footer-grid -->

            <!-- Footer Bottom -->
            <div class="footer-bottom">
                <p class="footer-copy">
                    &copy; <?php echo esc_html( date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. All rights reserved.
                </p>
                <div class="footer-legal-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Service</a>
                    <a href="#">Cookie Policy</a>
                </div>
            </div>

        </div><!-- .container -->
    </div><!-- .footer-body -->

</footer><!-- #site-footer -->

<?php wp_footer(); ?>
</body>
</html>
